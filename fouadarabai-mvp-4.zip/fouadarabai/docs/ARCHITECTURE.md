# FouadArabAI — Architecture

## Stack
- **Framework:** Next.js 14 (App Router, React Server Components)
- **Language:** TypeScript (strict mode)
- **Styling:** Tailwind CSS, custom design tokens (see `tailwind.config.ts`)
- **Data:** PostgreSQL via Prisma ORM
- **Hosting:** Vercel (Edge-friendly, but this app uses standard Node runtime because of Prisma)

## Rendering strategy
- Homepage, tools directory, tool details, and category pages are **Server Components** that query
  Prisma directly at request time. This keeps the MVP simple (no separate API layer needed) while
  still being fast, since Vercel + a nearby Postgres region (e.g. `fra1` for MENA/Europe) keeps
  round-trips low.
- A single `/api/search` route exists as a thin JSON endpoint for future client-side/instant search
  widgets, but the MVP's directory page works without JavaScript via a normal form GET.

## Internationalization (Arabic-first, bilingual)
The MVP intentionally avoids a full i18n routing library (e.g. next-intl) to keep the codebase small.
Instead:
- Every content table stores **both** `*_En` and `*_Ar` fields directly (e.g. `nameEn`/`nameAr`).
- The active locale is stored in a cookie (`fa_locale`), read server-side in `src/lib/i18n.ts`.
- `<html dir="rtl|ltr" lang="ar|en">` is set in the root layout based on that cookie, so the entire
  app flips direction correctly (RTL for Arabic, LTR for English).
- The `LanguageToggle` client component flips the cookie and calls `router.refresh()`.

This is a deliberate simplification. If the business later wants localized URLs (`/en/tools` vs
`/ar/tools`) for stronger per-language SEO, migrating to `next-intl` is a contained change — the
bilingual data model does not need to change.

## Affiliate & sponsored architecture
- `Tool.websiteUrl` is the canonical/original URL (used for structured data, screenshots, etc).
- `Tool.affiliateUrl` is optional. When present, outbound clicks route through it instead.
- All outbound clicks go through `/out/[slug]`, a route handler that:
  1. Looks up the tool
  2. Increments `clickCount` (fire-and-forget, non-blocking)
  3. Redirects (302) to `affiliateUrl ?? websiteUrl`
- `/out/*` is disallowed in `robots.txt` so redirect URLs are never indexed, and the visible tool
  page link uses `rel="sponsored nofollow noopener"` to stay compliant with Google's affiliate-link
  guidelines.
- `Tool.isSponsored` + `sponsorRank` + `sponsoredUntil` control paid placement. Expired sponsorships
  fall out of `getSponsoredTools()` automatically because of the `sponsoredUntil >= now` filter.

## Data access layer
All Prisma queries live in `src/lib/data.ts`, not scattered across pages. Pages/route handlers call
these functions. This is the seam future features (caching, Redis, full-text search service) can be
inserted behind without touching UI code.

## Search (MVP)
Uses Postgres `ILIKE`-style `contains` filtering across name/tagline/description in both languages
(`src/lib/data.ts#getAllTools`). This is intentionally simple and fast enough for a directory with
hundreds to low-thousands of tools. The schema already reserves `searchTextEn`/`searchTextAr`
`tsvector`-ready columns for a future upgrade to Postgres full-text search (`ts_rank`, `GIN` index)
without a breaking migration — see `docs/FUTURE_ROADMAP.md`.

## Growth-ready extension points
The schema and folder layout were designed so these can be added later without refactors:
- `User` model already exists for future auth (NextAuth/Clerk) tied to reviews/submissions/memberships.
- `PricingModel` enum can grow (e.g. `SUBSCRIPTION_TIERED`) without touching queries.
- Marketplace/Academy/Community would become new top-level route groups (`src/app/(marketplace)/...`)
  and new Prisma models referencing `Tool`/`User`, not a rewrite of existing ones.
