# Future Roadmap

The MVP intentionally excludes these. Each is designed to layer on top of the current schema and
folder structure without a rewrite.

## 1. Authentication
Add NextAuth.js (or Clerk) on top of the existing `User` model. Enables reviews, tool submissions
by third parties, and saved/favorited tools.

## 2. Full-text search upgrade
`Tool.searchTextEn` / `searchTextAr` columns already exist. Populate them with a Postgres trigger or
on-write, add a `GIN` index, and switch `getAllTools()` to `to_tsquery`/`ts_rank` ordering for
relevance-ranked search instead of `contains` matching.

## 3. Tool submission + moderation queue
A public "Submit your AI tool" form writing to `Tool` with `isPublished: false` until an admin
approves it. Needs a lightweight admin view (could start as a Prisma Studio-gated flow, then a real
`/admin` route group once volume justifies it).

## 4. Reviews & ratings
New `Review` model (`toolId`, `userId`, `rating`, `comment`, bilingual body). Aggregate average
rating displayed on `ToolCard` and the tool detail page.

## 5. Marketplace
New route group `src/app/(marketplace)/marketplace`, new models (`Product`, `Order`, `Payment`).
Reuses `Category`/`Tag` where sensible. Payments via Stripe.

## 6. Academy
New route group `src/app/(academy)/academy`, models (`Course`, `Lesson`, `Enrollment`). Could
reference `Tool` (e.g. "Courses about this tool").

## 7. Community
New route group `src/app/(community)/community`, models (`Post`, `Comment`). Ties into `User`.

## 8. Memberships / paid tiers
`Membership` model tied to `User`, gating premium directory features (advanced filters, early
access to new tools, ad-free browsing) — a natural home for recurring revenue once traffic is
established.

## 9. Localized URLs
If organic search performance calls for it, migrate the cookie-based locale switch to `next-intl`
with `/ar/...` and `/en/...` paths so each language can rank independently. The bilingual data model
already in place makes this a routing-layer change, not a data migration.

## 10. Advanced affiliate analytics
Track click-through by referrer/campaign using UTM parameters appended to `/out/[slug]?utm_source=...`,
stored alongside `clickCount` in a dedicated `ClickEvent` model for time-series reporting.
