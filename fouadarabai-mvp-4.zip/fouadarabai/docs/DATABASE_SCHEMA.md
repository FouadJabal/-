# Database Schema

Full source of truth: `prisma/schema.prisma`. Summary below.

## Category
| Field | Type | Notes |
|---|---|---|
| slug | String (unique) | URL segment, e.g. `writing` |
| nameEn / nameAr | String | Bilingual display name |
| descriptionEn / descriptionAr | String? | Optional category intro copy |
| icon | String? | Icon key rendered by the UI |
| sortOrder | Int | Controls homepage/categories ordering |

## Tool
| Field | Type | Notes |
|---|---|---|
| slug | String (unique) | e.g. `claude` |
| nameEn / nameAr, taglineEn / taglineAr, descriptionEn / descriptionAr | String | Bilingual content |
| logoUrl, screenshotUrl | String? | Media |
| websiteUrl | String | Canonical destination |
| affiliateUrl | String? | If set, outbound clicks route here instead (see ARCHITECTURE.md) |
| pricingModel | enum `PricingModel` | FREE / FREEMIUM / PAID / CONTACT_FOR_PRICING |
| startingPrice | String? | Free-form label, e.g. `$19/mo` |
| categoryId | relation → Category | One category per tool for the MVP |
| tags | relation → ToolTag → Tag | Many-to-many, optional filtering later |
| isSponsored, sponsoredUntil, sponsorRank | — | Paid placement controls |
| isFeatured, isVerified, isPublished | Boolean | Editorial controls |
| viewCount, clickCount | Int | Basic analytics, incremented server-side |
| searchTextEn, searchTextAr | String? | Reserved for future Postgres full-text search upgrade |

## Tag / ToolTag
Standard many-to-many join table. Not surfaced in the MVP UI yet, but modeled now so tag-based
filtering can ship later without a migration that touches `Tool`.

## User
Minimal placeholder (`id`, `email`, `name`) so future auth/reviews/submissions/memberships have a
stable foreign key target from day one.

## Migrations workflow
This project uses **versioned Prisma migrations**, not `db push`. The initial migration already
exists at `prisma/migrations/20260706120000_init/migration.sql` and matches `schema.prisma` exactly.

```bash
# generate the Prisma Client
npx prisma generate

# apply all pending migrations to the target DATABASE_URL
npx prisma migrate deploy

# seed sample data (optional, safe to run multiple times — uses upsert)
npm run db:seed
```

`npm run build` already runs `prisma generate && prisma migrate deploy && next build`, so every
Vercel deploy automatically applies any new migrations to the production database before building.

### Changing the schema later
```bash
# 1. Edit prisma/schema.prisma
# 2. Generate a new migration against your local/dev database:
npm run db:migrate -- --name describe_your_change
# 3. Commit the new folder under prisma/migrations/ along with your code change
# 4. Deploy as usual — `prisma migrate deploy` picks it up automatically
```
