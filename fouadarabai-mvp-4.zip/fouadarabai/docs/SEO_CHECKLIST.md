# SEO Checklist

## Implemented in this MVP
- [x] Per-page `<title>` / meta description via Next.js Metadata API (homepage, tools, tool detail, categories, category detail)
- [x] Canonical URLs on all listing/detail pages (`alternates.canonical`)
- [x] OpenGraph tags (site-wide default + per-tool override with screenshot image)
- [x] `robots.txt` generated dynamically, disallowing `/api/` and `/out/` (keeps redirect/affiliate
      URLs out of the index)
- [x] `sitemap.xml` generated dynamically from the live database (tools + categories + static routes)
- [x] Structured data: `WebSite` + `SearchAction` on homepage, `SoftwareApplication` on tool pages
- [x] Semantic HTML (`<nav>`, `<main>`, `<h1>` per page, `<dl>` for spec-like data)
- [x] `lang` and `dir` attributes correctly set per locale for proper Arabic indexing

## Still to do before/after launch
- [ ] Write unique, keyword-considered Arabic + English descriptions per tool (avoid thin/duplicate content)
- [ ] Add an `og-image` (1200×630) per tool or a strong site-wide default in `/public`
- [ ] Register the domain in Google Search Console and Bing Webmaster Tools, submit sitemap
- [ ] Set up basic analytics (e.g. Vercel Analytics or Plausible) to track organic traffic
- [ ] Internal linking: as tool count grows, ensure category pages link out to enough individual tools
- [ ] Consider localized paths (`/ar/...`, `/en/...`) later if Arabic and English content should rank
      independently — current cookie-based approach serves one canonical URL per page with content
      based on cookie, which is fine for MVP but not optimal for language-specific SEO long-term
