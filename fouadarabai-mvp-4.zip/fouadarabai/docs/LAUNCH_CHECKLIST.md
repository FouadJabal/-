# Launch Checklist

## Content
- [ ] At least 6 categories populated with correct bilingual names
- [ ] At least 30–50 tools added (seed data has 4 as examples — replace/expand before public launch)
- [ ] Every tool has: logo, tagline (both languages), description (both languages), pricing
- [ ] Sponsored tools reviewed for `sponsoredUntil` dates so nothing runs indefinitely by accident
- [ ] Affiliate URLs tested — clicking "Visit Website" lands on the correct destination

## Technical
- [ ] `DATABASE_URL` points to production Postgres, not a local/dev database
- [ ] `NEXT_PUBLIC_SITE_URL` matches the real production domain exactly
- [ ] `prisma migrate deploy` has run successfully against production database (happens automatically as part of `npm run build`)
- [ ] Seed or real content loaded
- [ ] Production build succeeds on Vercel with no errors
- [ ] Custom domain connected and HTTPS active (automatic via Vercel)
- [ ] 404 page checked (default Next.js not-found renders correctly)

## SEO
- [ ] `/sitemap.xml` returns all tools/categories
- [ ] `/robots.txt` correctly disallows `/api/` and `/out/`
- [ ] Titles/descriptions render correctly per page (check a tool page, a category page)
- [ ] Structured data validates in Google's Rich Results Test
- [ ] Submit sitemap in Google Search Console after launch

## Quality
- [ ] Test on mobile viewport (search, RTL Arabic layout, LTR English layout)
- [ ] Keyboard navigation works (tab through header, search, cards)
- [ ] Language toggle correctly flips `dir` and persists across navigation
- [ ] No console errors in browser dev tools on core pages

## Legal / trust
- [ ] Sponsored tools visibly labeled ("Sponsored" badge — already implemented)
- [ ] Outbound affiliate links use `rel="sponsored nofollow"` (already implemented)
- [ ] Add a simple About/Contact page or footer note if required by your jurisdiction for affiliate
      disclosure (not included in MVP scope — add before heavy affiliate monetization)
