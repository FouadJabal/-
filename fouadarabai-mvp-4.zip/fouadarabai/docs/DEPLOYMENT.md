# Deployment Guide — Vercel

## 1. Create a Postgres database
Pick one (all have free/cheap tiers and work well with Prisma + Vercel):
- **Vercel Postgres** (simplest, same dashboard as your deployment)
- **Neon** (serverless Postgres, generous free tier)
- **Supabase** (Postgres + extras, if you'll want auth/storage later)

Copy the connection string — you'll need it as `DATABASE_URL`.

## 2. Push the code to GitHub
```bash
git init
git add .
git commit -m "Initial FouadArabAI MVP"
git branch -M main
git remote add origin <your-repo-url>
git push -u origin main
```

## 3. Import the project into Vercel
1. Go to vercel.com → **Add New → Project** → import the GitHub repo.
2. Framework preset should auto-detect **Next.js**.
3. Under **Environment Variables**, add everything from `.env.example` with real values
   (see `docs/ENVIRONMENT_VARIABLES.md`).
4. Deploy.

## 4. Initialize the database schema
The build command (`prisma generate && prisma migrate deploy && next build`) already applies
migrations automatically on every Vercel deploy — you do not need a separate manual step for
schema setup. Optionally, seed sample data once so the site isn't empty on first launch:
```bash
npm install
# with DATABASE_URL pointed at your production database:
npm run db:seed
```

## 5. Verify the build
Vercel runs `npm run build`, which executes `prisma generate && prisma migrate deploy && next build`
(see `package.json`). If the build fails on `prisma migrate deploy`, double check `DATABASE_URL` is
set correctly in the Vercel project's environment variables for the **Production** environment, and
that the database is reachable from Vercel's build network (some providers require enabling
external/pooled connections explicitly — e.g. Supabase's "connection pooling" string).

## 6. Post-deploy checks
- Visit `/` — homepage loads, hero renders, language toggle switches direction (RTL ↔ LTR).
- Visit `/tools` — search and category filters work.
- Visit `/tools/claude` (or any seeded slug) — tool page loads, "Visit Website" link redirects via `/out/claude`.
- Visit `/sitemap.xml` and `/robots.txt` — both render.
- Run the site through Google's Rich Results Test to confirm the `SoftwareApplication` and
  `WebSite` structured data validate.

## 7. Connect the domain
In Vercel → Project → Settings → Domains, add your production domain (e.g. `fouadarabai.com`) and
update `NEXT_PUBLIC_SITE_URL` in the environment variables to match exactly (no trailing slash).
Redeploy after changing environment variables.
