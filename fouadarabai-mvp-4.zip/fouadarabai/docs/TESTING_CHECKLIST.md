# Testing / QA Checklist

## Functional
- [ ] Homepage loads and displays sponsored, featured, and category sections
- [ ] Search bar on homepage redirects to `/tools?q=...` with correct results
- [ ] Search bar on `/tools` page filters results in place
- [ ] Category filter chips on `/tools` correctly filter and highlight the active category
- [ ] Pagination on `/tools` produces correct page links and result sets
- [ ] Tool detail page renders all bilingual fields correctly
- [ ] "Visit Website" button redirects through `/out/[slug]` to the correct final URL
- [ ] Click count (`clickCount`) increments in the database after visiting `/out/[slug]`
- [ ] View count (`viewCount`) increments after visiting a tool detail page
- [ ] Category detail page lists only tools in that category
- [ ] Language toggle switches all UI strings and flips `dir` between `rtl`/`ltr`
- [ ] 404 page appears for unknown tool/category slugs

## Cross-cutting
- [ ] Arabic text renders correctly (no mojibake, correct font, correct RTL alignment/mirroring of icons)
- [ ] English text renders correctly in LTR
- [ ] Mobile viewport (375px width) — no horizontal scroll, tap targets big enough
- [ ] Tablet and desktop breakpoints look intentional, not just stretched mobile
- [ ] Lighthouse: Performance, Accessibility, Best Practices, SEO all scored (target 90+ where feasible)
- [ ] No unhandled promise rejections / console errors on core pages

## Data integrity
- [ ] Deleting/unpublishing a tool (`isPublished: false`) removes it from directory, homepage, sitemap
- [ ] Expired `sponsoredUntil` correctly removes a tool from the sponsored section
- [ ] Duplicate slugs are rejected (enforced by Prisma `@unique`)

## Before marking Phase 12 (QA) complete
Fix every issue found above. Do not proceed to Phase 13 (production prep) with known critical
issues (broken redirects, incorrect RTL/LTR, broken search, or build failures).
