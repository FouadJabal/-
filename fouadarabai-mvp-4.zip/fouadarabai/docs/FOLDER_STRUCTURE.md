# Final Folder Structure

```
fouadarabai/
├── prisma/
│   ├── schema.prisma          # Data model (Category, Tool, Tag, ToolTag, User)
│   └── seed.ts                # Sample bilingual data
├── src/
│   ├── app/
│   │   ├── layout.tsx         # Root layout: fonts, dir/lang, header/footer
│   │   ├── globals.css
│   │   ├── page.tsx           # Homepage
│   │   ├── sitemap.ts         # /sitemap.xml
│   │   ├── robots.ts          # /robots.txt
│   │   ├── tools/
│   │   │   ├── page.tsx       # Directory: search + category filter + pagination
│   │   │   └── [slug]/page.tsx  # Tool details
│   │   ├── categories/
│   │   │   ├── page.tsx       # Categories index
│   │   │   └── [slug]/page.tsx  # Tools within one category
│   │   ├── out/[slug]/route.ts  # Affiliate/outbound redirect + click tracking
│   │   └── api/search/route.ts  # JSON search endpoint (future instant-search UI)
│   ├── components/
│   │   ├── Header.tsx
│   │   ├── Footer.tsx
│   │   ├── Container.tsx
│   │   ├── SearchBar.tsx
│   │   ├── ToolCard.tsx
│   │   ├── CategoryCard.tsx
│   │   ├── SponsoredBadge.tsx
│   │   └── LanguageToggle.tsx
│   └── lib/
│       ├── prisma.ts          # Prisma client singleton
│       ├── data.ts            # All database queries (data access layer)
│       ├── i18n.ts            # Bilingual dictionary + locale helpers
│       └── utils.ts           # cn(), siteUrl()
├── docs/                      # This documentation set
├── public/                    # Static assets (logos, og-image, favicons)
├── .env.example
├── next.config.mjs
├── tailwind.config.ts
├── vercel.json
└── package.json
```

## Reserved (not built in MVP, but planned for)
Future modules should live as their own route groups and Prisma models, e.g.:
```
src/app/(marketplace)/marketplace/...
src/app/(academy)/academy/...
src/app/(community)/community/...
prisma/schema.prisma  → add Order, Product, Course, Post, Membership models
```
