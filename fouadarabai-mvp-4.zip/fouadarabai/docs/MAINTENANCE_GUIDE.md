# Maintenance Guide

## Adding a new tool
Currently done via direct database access (Prisma Studio or a SQL/Prisma script) since the MVP has
no admin UI (out of scope — see Future Roadmap). Recommended interim workflow:
```bash
npx prisma studio
```
Open the `Tool` table, click "Add record", fill in both language fields, category, pricing, and
sponsorship flags if applicable.

## Rotating sponsored placements
Update `isSponsored`, `sponsorRank`, and `sponsoredUntil` on the relevant `Tool` rows. The homepage
and directory automatically stop showing a tool as sponsored once `sponsoredUntil` passes — no code
changes needed.

## Adding a category
Add a row to `Category` with a unique `slug`, both language names, and a `sortOrder` (lower numbers
appear first). No code deploy required.

## Database backups
Whichever Postgres provider you use (Vercel Postgres / Neon / Supabase), enable automatic daily
backups in its dashboard. Test a restore at least once before you rely on it.

## Monitoring
- Watch Vercel's build logs after every deploy for Prisma generation errors.
- Periodically check `viewCount`/`clickCount` to see which tools are actually driving traffic —
  useful both for editorial decisions and for pitching future sponsors on real numbers.

## Dependency updates
This is a small, dependency-light stack on purpose. Every few months:
```bash
npm outdated
npm update
npx prisma -v   # confirm Prisma Client and CLI versions still match
```
Re-run the full Testing Checklist after any major version bump (especially Next.js or Prisma).

## When to add caching
If traffic grows and database load becomes a concern, the data access layer in `src/lib/data.ts` is
the single place to add caching (e.g. Next.js `unstable_cache`, or a Redis layer) without touching
any page component.
