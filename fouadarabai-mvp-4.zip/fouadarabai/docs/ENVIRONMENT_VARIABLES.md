# Environment Variables

| Variable | Required | Example | Notes |
|---|---|---|---|
| `DATABASE_URL` | Yes | `postgresql://user:pass@host:5432/db?schema=public` | Production Postgres connection string |
| `NEXT_PUBLIC_SITE_URL` | Yes | `https://fouadarabai.com` | No trailing slash. Used for canonical URLs, sitemap, OG tags |
| `NEXT_PUBLIC_DEFAULT_LOCALE` | No | `ar` | Default locale for first-time visitors without a cookie yet |
| `GOOGLE_SITE_VERIFICATION` | No | (token from Search Console) | Add once you verify the domain |

Set all of these in Vercel under **Project → Settings → Environment Variables**, for both
**Production** and **Preview** environments (use a separate/staging database for Preview if
possible, so test data never touches production).

Never commit a real `.env` file — `.gitignore` already excludes it. Use `.env.example` as the
template for local development (`cp .env.example .env`).
