import { PrismaClient, PricingModel } from "@prisma/client";

const prisma = new PrismaClient();

async function main() {
  const categories = [
    { slug: "writing", nameEn: "Writing & Content", nameAr: "الكتابة والمحتوى", icon: "pen" },
    { slug: "image-generation", nameEn: "Image Generation", nameAr: "توليد الصور", icon: "image" },
    { slug: "productivity", nameEn: "Productivity", nameAr: "الإنتاجية", icon: "bolt" },
    { slug: "coding", nameEn: "Coding & Development", nameAr: "البرمجة والتطوير", icon: "code" },
    { slug: "video-audio", nameEn: "Video & Audio", nameAr: "الفيديو والصوت", icon: "film" },
    { slug: "business", nameEn: "Business & Marketing", nameAr: "الأعمال والتسويق", icon: "briefcase" }
  ];

  for (const [i, c] of categories.entries()) {
    await prisma.category.upsert({
      where: { slug: c.slug },
      update: {},
      create: { ...c, sortOrder: i }
    });
  }

  const writing = await prisma.category.findUniqueOrThrow({ where: { slug: "writing" } });
  const image = await prisma.category.findUniqueOrThrow({ where: { slug: "image-generation" } });
  const coding = await prisma.category.findUniqueOrThrow({ where: { slug: "coding" } });
  const productivity = await prisma.category.findUniqueOrThrow({ where: { slug: "productivity" } });

  const tools = [
    {
      slug: "claude",
      nameEn: "Claude",
      nameAr: "كلود",
      taglineEn: "A conversational AI assistant for writing, analysis and code.",
      taglineAr: "مساعد ذكاء اصطناعي محادثي للكتابة والتحليل والبرمجة.",
      descriptionEn: "Claude helps you write, research, summarize documents and write code through natural conversation.",
      descriptionAr: "يساعدك كلود على الكتابة والبحث وتلخيص المستندات وكتابة الأكواد البرمجية من خلال محادثة طبيعية.",
      websiteUrl: "https://claude.ai",
      pricingModel: PricingModel.FREEMIUM,
      startingPrice: "Free / $20/mo",
      categoryId: writing.id,
      isFeatured: true,
      isVerified: true
    },
    {
      slug: "midjourney",
      nameEn: "Midjourney",
      nameAr: "ميدجورني",
      taglineEn: "Generate striking AI images from text prompts.",
      taglineAr: "أنشئ صورًا مذهلة بالذكاء الاصطناعي من نصوص وصفية.",
      descriptionEn: "Midjourney turns short text prompts into high-quality, artistic images in seconds.",
      descriptionAr: "يحوّل ميدجورني الأوصاف النصية القصيرة إلى صور فنية عالية الجودة خلال ثوانٍ.",
      websiteUrl: "https://midjourney.com",
      pricingModel: PricingModel.PAID,
      startingPrice: "$10/mo",
      categoryId: image.id,
      isSponsored: true,
      sponsorRank: 1,
      sponsoredUntil: new Date(Date.now() + 1000 * 60 * 60 * 24 * 30)
    },
    {
      slug: "cursor",
      nameEn: "Cursor",
      nameAr: "كيرسر",
      taglineEn: "An AI-first code editor that writes and refactors with you.",
      taglineAr: "محرر أكواد مبني على الذكاء الاصطناعي يكتب وينظم الكود معك.",
      descriptionEn: "Cursor is a code editor built for pair-programming with AI, from autocomplete to full refactors.",
      descriptionAr: "كيرسر محرر أكواد مصمم للبرمجة الزوجية مع الذكاء الاصطناعي، من الإكمال التلقائي إلى إعادة الهيكلة الكاملة.",
      websiteUrl: "https://cursor.sh",
      pricingModel: PricingModel.FREEMIUM,
      startingPrice: "Free / $20/mo",
      categoryId: coding.id,
      isFeatured: true
    },
    {
      slug: "notion-ai",
      nameEn: "Notion AI",
      nameAr: "نوشن للذكاء الاصطناعي",
      taglineEn: "Write, summarize and organize notes with AI built into Notion.",
      taglineAr: "اكتب ولخّص ونظّم ملاحظاتك بذكاء اصطناعي مدمج داخل نوشن.",
      descriptionEn: "Notion AI adds writing and summarizing tools directly inside your existing Notion workspace.",
      descriptionAr: "يضيف نوشن AI أدوات كتابة وتلخيص مباشرة داخل مساحة عملك في نوشن.",
      websiteUrl: "https://notion.so",
      pricingModel: PricingModel.PAID,
      startingPrice: "$10/mo",
      categoryId: productivity.id
    }
  ];

  for (const t of tools) {
    await prisma.tool.upsert({
      where: { slug: t.slug },
      update: {},
      create: t
    });
  }

  console.log("Seed complete.");
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
