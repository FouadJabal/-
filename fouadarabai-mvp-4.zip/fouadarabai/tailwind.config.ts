import type { Config } from "tailwindcss";

const config: Config = {
  darkMode: "class",
  content: ["./src/**/*.{js,ts,jsx,tsx,mdx}"],
  theme: {
    extend: {
      colors: {
        // Each token reads its RGB channels from a CSS variable (defined in
        // globals.css for :root and .dark), so `bg-ink/70` etc. still work
        // via Tailwind's opacity modifier while the underlying value flips
        // with the "dark" class.
        ink: "rgb(var(--color-ink) / <alpha-value>)",
        paper: "rgb(var(--color-paper) / <alpha-value>)",
        indigo: {
          DEFAULT: "rgb(var(--color-indigo) / <alpha-value>)",
          dark: "rgb(var(--color-indigo-dark) / <alpha-value>)"
        },
        gold: {
          DEFAULT: "rgb(var(--color-gold) / <alpha-value>)",
          light: "rgb(var(--color-gold-light) / <alpha-value>)"
        },
        teal: {
          DEFAULT: "rgb(var(--color-teal) / <alpha-value>)"
        },
        line: "rgb(var(--color-line) / <alpha-value>)"
      },
      fontFamily: {
        display: ["var(--font-cairo)", "sans-serif"],
        body: ["var(--font-inter)", "sans-serif"],
        arabic: ["var(--font-tajawal)", "sans-serif"]
      },
      borderRadius: {
        xl2: "1.25rem"
      }
    }
  },
  plugins: []
};

export default config;
