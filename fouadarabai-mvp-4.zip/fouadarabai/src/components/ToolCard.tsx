import Link from "next/link";
import Image from "next/image";
import type { Locale } from "@/lib/i18n";
import { pick, t } from "@/lib/i18n";
import { SponsoredBadge } from "./SponsoredBadge";

type ToolCardData = {
  slug: string;
  nameEn: string;
  nameAr: string;
  taglineEn: string;
  taglineAr: string;
  logoUrl: string | null;
  isSponsored: boolean;
  isVerified: boolean;
  startingPrice: string | null;
  category: { nameEn: string; nameAr: string };
};

export function ToolCard({ tool, locale }: { tool: ToolCardData; locale: Locale }) {
  const dict = t(locale);
  const name = pick(tool, "name", locale);
  const tagline = pick(tool, "tagline", locale);
  const categoryName = pick(tool.category, "name", locale);

  return (
    <Link
      href={`/tools/${tool.slug}`}
      className="group flex flex-col rounded-xl2 border border-line bg-paper p-5 transition hover:-translate-y-0.5 hover:shadow-md"
    >
      <div className="mb-3 flex items-start justify-between gap-2">
        <div className="flex h-11 w-11 items-center justify-center overflow-hidden rounded-lg bg-ink/5">
          {tool.logoUrl ? (
            <Image src={tool.logoUrl} alt={name} width={44} height={44} className="object-cover" />
          ) : (
            <span className="font-display text-lg font-bold text-indigo">{name.charAt(0)}</span>
          )}
        </div>
        {tool.isSponsored && <SponsoredBadge label={dict.sponsored} />}
      </div>

      <h3 className="font-display text-base font-bold text-ink group-hover:text-indigo">{name}</h3>
      <p className="mt-1 line-clamp-2 font-body text-sm text-ink/70">{tagline}</p>

      <div className="mt-4 flex items-center justify-between text-xs text-ink/60">
        <span className="rounded-full bg-ink/5 px-2.5 py-1">{categoryName}</span>
        {tool.startingPrice && <span className="font-medium text-teal">{tool.startingPrice}</span>}
      </div>
    </Link>
  );
}
