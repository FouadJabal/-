"use client";

import { useRouter } from "next/navigation";
import type { Locale } from "@/lib/i18n";
import { LOCALE_COOKIE } from "@/lib/i18n";

export function LanguageToggle({ locale, label }: { locale: Locale; label: string }) {
  const router = useRouter();

  function switchLocale() {
    const next: Locale = locale === "ar" ? "en" : "ar";
    document.cookie = `${LOCALE_COOKIE}=${next}; path=/; max-age=31536000`;
    router.refresh();
  }

  return (
    <button
      onClick={switchLocale}
      className="rounded-full border border-line px-4 py-1.5 text-sm font-medium text-ink transition hover:border-indigo hover:text-indigo"
      aria-label="Switch language"
    >
      {label}
    </button>
  );
}
