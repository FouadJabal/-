import Link from "next/link";
import type { Locale } from "@/lib/i18n";
import { pick } from "@/lib/i18n";

type CategoryCardData = {
  slug: string;
  nameEn: string;
  nameAr: string;
  _count: { tools: number };
};

export function CategoryCard({ category, locale }: { category: CategoryCardData; locale: Locale }) {
  const name = pick(category, "name", locale);

  return (
    <Link
      href={`/categories/${category.slug}`}
      className="flex flex-col rounded-xl2 border border-line bg-paper p-5 transition hover:-translate-y-0.5 hover:border-indigo hover:shadow-md"
    >
      <h3 className="font-display text-base font-bold text-ink">{name}</h3>
      <p className="mt-1 font-body text-sm text-ink/60">
        {category._count.tools} {locale === "ar" ? "أداة" : "tools"}
      </p>
    </Link>
  );
}
