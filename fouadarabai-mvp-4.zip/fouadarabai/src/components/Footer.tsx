import type { Locale } from "@/lib/i18n";
import { t } from "@/lib/i18n";
import { Container } from "./Container";

export function Footer({ locale }: { locale: Locale }) {
  const dict = t(locale);
  const year = new Date().getFullYear();

  return (
    <footer className="mt-24 border-t border-line py-10">
      <Container>
        <div className="flex flex-col items-center justify-between gap-4 text-sm text-ink/60 sm:flex-row">
          <p className="font-display font-semibold text-ink">{dict.siteName}</p>
          <p>
            © {year} {dict.siteName} — {dict.footerRights}
          </p>
        </div>
      </Container>
    </footer>
  );
}
