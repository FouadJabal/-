"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";

export function SearchBar({
  placeholder,
  defaultValue = ""
}: {
  placeholder: string;
  defaultValue?: string;
}) {
  const router = useRouter();
  const [value, setValue] = useState(defaultValue);

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    const params = new URLSearchParams();
    if (value.trim()) params.set("q", value.trim());
    router.push(`/tools?${params.toString()}`);
  }

  return (
    <form onSubmit={handleSubmit} className="flex w-full max-w-xl gap-2" role="search">
      <input
        type="search"
        value={value}
        onChange={(e) => setValue(e.target.value)}
        placeholder={placeholder}
        className="w-full rounded-xl2 border border-line bg-paper px-5 py-3 font-body text-ink shadow-sm outline-none transition focus:border-indigo focus:ring-2 focus:ring-indigo/20"
        aria-label={placeholder}
      />
      <button
        type="submit"
        className="shrink-0 rounded-xl2 bg-indigo px-5 py-3 font-medium text-white transition hover:bg-indigo-dark"
      >
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" aria-hidden="true">
          <path
            d="M21 21l-4.35-4.35m0 0A7.5 7.5 0 1 0 5.5 5.5a7.5 7.5 0 0 0 11.15 11.15Z"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
          />
        </svg>
      </button>
    </form>
  );
}
