import Link from "next/link";
import type { Locale } from "@/lib/i18n";
import { t } from "@/lib/i18n";
import { LanguageToggle } from "./LanguageToggle";
import { Container } from "./Container";

export function Header({ locale }: { locale: Locale }) {
  const dict = t(locale);

  return (
    <header className="sticky top-0 z-40 border-b border-line bg-paper/90 backdrop-blur">
      <Container>
        <div className="flex h-16 items-center justify-between">
          <Link href="/" className="font-display text-lg font-bold tracking-tight text-ink">
            {dict.siteName}
          </Link>

          <nav className="hidden items-center gap-6 font-body text-sm text-ink/80 md:flex">
            <Link href="/" className="hover:text-indigo">{dict.nav.home}</Link>
            <Link href="/tools" className="hover:text-indigo">{dict.nav.tools}</Link>
            <Link href="/categories" className="hover:text-indigo">{dict.nav.categories}</Link>
          </nav>

          <LanguageToggle locale={locale} label={dict.switchLang} />
        </div>
      </Container>
    </header>
  );
}
