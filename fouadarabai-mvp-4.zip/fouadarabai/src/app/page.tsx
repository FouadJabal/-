import Link from "next/link";
import { getLocaleFromCookies, t } from "@/lib/i18n";
import { Container } from "@/components/Container";
import { SearchBar } from "@/components/SearchBar";
import { ToolCard } from "@/components/ToolCard";
import { CategoryCard } from "@/components/CategoryCard";
import { getCategories, getFeaturedTools, getSponsoredTools } from "@/lib/data";
import { siteUrl } from "@/lib/utils";

export default async function HomePage() {
  const locale = getLocaleFromCookies();
  const dict = t(locale);

  const [categories, featured, sponsored] = await Promise.all([
    getCategories(),
    getFeaturedTools(8),
    getSponsoredTools(3)
  ]);

  const jsonLd = {
    "@context": "https://schema.org",
    "@type": "WebSite",
    name: dict.siteName,
    url: siteUrl(),
    potentialAction: {
      "@type": "SearchAction",
      target: `${siteUrl()}/tools?q={search_term_string}`,
      "query-input": "required name=search_term_string"
    }
  };

  return (
    <>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }}
      />

      <section className="border-b border-line bg-gradient-to-b from-indigo/5 to-transparent py-20">
        <Container>
          <div className="mx-auto max-w-3xl text-center">
            <h1 className="font-display text-4xl font-extrabold leading-tight text-ink sm:text-5xl">
              {dict.tagline}
            </h1>
            <div className="mt-8 flex justify-center">
              <SearchBar placeholder={dict.searchPlaceholder} />
            </div>
            <div className="mt-6 flex justify-center gap-4 text-sm">
              <Link href="/tools" className="rounded-full bg-indigo px-5 py-2 font-medium text-white hover:bg-indigo-dark">
                {dict.heroCta}
              </Link>
              <Link href="/categories" className="rounded-full border border-line px-5 py-2 font-medium text-ink hover:border-indigo hover:text-indigo">
                {dict.heroSubCta}
              </Link>
            </div>
          </div>
        </Container>
      </section>

      {sponsored.length > 0 && (
        <section className="py-14">
          <Container>
            <h2 className="mb-6 font-display text-xl font-bold text-ink">{dict.sponsored}</h2>
            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
              {sponsored.map((tool) => (
                <ToolCard key={tool.id} tool={tool} locale={locale} />
              ))}
            </div>
          </Container>
        </section>
      )}

      <section className="py-14">
        <Container>
          <h2 className="mb-6 font-display text-xl font-bold text-ink">{dict.featured}</h2>
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {featured.map((tool) => (
              <ToolCard key={tool.id} tool={tool} locale={locale} />
            ))}
          </div>
        </Container>
      </section>

      <section className="py-14">
        <Container>
          <h2 className="mb-6 font-display text-xl font-bold text-ink">{dict.categories}</h2>
          <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-6">
            {categories.map((category) => (
              <CategoryCard key={category.id} category={category} locale={locale} />
            ))}
          </div>
        </Container>
      </section>
    </>
  );
}
