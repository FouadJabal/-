import Link from "next/link";
import { getLocaleFromCookies } from "@/lib/i18n";
import { Container } from "@/components/Container";

export default function NotFound() {
  const locale = getLocaleFromCookies();
  const isAr = locale === "ar";

  return (
    <Container>
      <div className="flex min-h-[50vh] flex-col items-center justify-center py-20 text-center">
        <h1 className="font-display text-5xl font-extrabold text-indigo">404</h1>
        <p className="mt-4 font-body text-ink/70">
          {isAr ? "لم يتم العثور على هذه الصفحة." : "This page could not be found."}
        </p>
        <Link href="/" className="mt-6 rounded-full bg-indigo px-5 py-2 font-medium text-white hover:bg-indigo-dark">
          {isAr ? "العودة للرئيسية" : "Back to Home"}
        </Link>
      </div>
    </Container>
  );
}
