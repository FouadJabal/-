import type { MetadataRoute } from "next";
import { prisma } from "@/lib/prisma";
import { siteUrl } from "@/lib/utils";

export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  const [tools, categories] = await Promise.all([
    prisma.tool.findMany({ where: { isPublished: true }, select: { slug: true, updatedAt: true } }),
    prisma.category.findMany({ select: { slug: true, updatedAt: true } })
  ]);

  const staticRoutes: MetadataRoute.Sitemap = [
    { url: siteUrl("/"), changeFrequency: "daily", priority: 1 },
    { url: siteUrl("/tools"), changeFrequency: "daily", priority: 0.9 },
    { url: siteUrl("/categories"), changeFrequency: "weekly", priority: 0.7 }
  ];

  const toolRoutes: MetadataRoute.Sitemap = tools.map((tool) => ({
    url: siteUrl(`/tools/${tool.slug}`),
    lastModified: tool.updatedAt,
    changeFrequency: "weekly",
    priority: 0.8
  }));

  const categoryRoutes: MetadataRoute.Sitemap = categories.map((category) => ({
    url: siteUrl(`/categories/${category.slug}`),
    lastModified: category.updatedAt,
    changeFrequency: "weekly",
    priority: 0.6
  }));

  return [...staticRoutes, ...toolRoutes, ...categoryRoutes];
}
