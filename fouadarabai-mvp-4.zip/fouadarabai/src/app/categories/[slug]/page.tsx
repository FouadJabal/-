import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { getLocaleFromCookies, pick, t } from "@/lib/i18n";
import { Container } from "@/components/Container";
import { ToolCard } from "@/components/ToolCard";
import { getAllTools, getCategoryBySlug } from "@/lib/data";
import { siteUrl } from "@/lib/utils";

export async function generateMetadata({
  params
}: {
  params: { slug: string };
}): Promise<Metadata> {
  const category = await getCategoryBySlug(params.slug);
  if (!category) return {};
  const locale = getLocaleFromCookies();
  const name = pick(category, "name", locale);

  return {
    title: name,
    description: pick(category, "description", locale) || name,
    alternates: { canonical: siteUrl(`/categories/${category.slug}`) }
  };
}

export default async function CategoryDetailsPage({ params }: { params: { slug: string } }) {
  const locale = getLocaleFromCookies();
  const dict = t(locale);

  const category = await getCategoryBySlug(params.slug);
  if (!category) notFound();

  const { items } = await getAllTools({ categorySlug: category.slug, pageSize: 48 });
  const name = pick(category, "name", locale);

  return (
    <Container>
      <div className="py-12">
        <h1 className="font-display text-3xl font-bold text-ink">{name}</h1>

        {items.length === 0 ? (
          <p className="mt-16 text-center font-body text-ink/60">{dict.noResults}</p>
        ) : (
          <div className="mt-8 grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {items.map((tool) => (
              <ToolCard key={tool.id} tool={tool} locale={locale} />
            ))}
          </div>
        )}
      </div>
    </Container>
  );
}
