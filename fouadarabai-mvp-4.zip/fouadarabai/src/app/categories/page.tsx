import type { Metadata } from "next";
import { getLocaleFromCookies, t } from "@/lib/i18n";
import { Container } from "@/components/Container";
import { CategoryCard } from "@/components/CategoryCard";
import { getCategories } from "@/lib/data";
import { siteUrl } from "@/lib/utils";

export async function generateMetadata(): Promise<Metadata> {
  const locale = getLocaleFromCookies();
  const isAr = locale === "ar";

  return {
    title: isAr ? "التصنيفات" : "Categories",
    description: isAr
      ? "تصفح أدوات الذكاء الاصطناعي حسب التصنيف على فؤاد آراب AI."
      : "Browse AI tools by category on FouadArabAI.",
    alternates: { canonical: siteUrl("/categories") }
  };
}

export default async function CategoriesPage() {
  const locale = getLocaleFromCookies();
  const dict = t(locale);
  const categories = await getCategories();

  return (
    <Container>
      <div className="py-12">
        <h1 className="font-display text-3xl font-bold text-ink">{dict.categories}</h1>
        <div className="mt-8 grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4">
          {categories.map((category) => (
            <CategoryCard key={category.id} category={category} locale={locale} />
          ))}
        </div>
      </div>
    </Container>
  );
}
