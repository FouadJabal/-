import { NextResponse } from "next/server";
import { getAllTools } from "@/lib/data";

export async function GET(req: Request) {
  const { searchParams } = new URL(req.url);
  const q = searchParams.get("q")?.trim() || undefined;
  const category = searchParams.get("category") || undefined;

  if (!q && !category) {
    return NextResponse.json({ items: [], total: 0 });
  }

  const { items, total } = await getAllTools({ query: q, categorySlug: category, pageSize: 10 });

  return NextResponse.json({
    total,
    items: items.map((tool) => ({
      slug: tool.slug,
      nameEn: tool.nameEn,
      nameAr: tool.nameAr,
      taglineEn: tool.taglineEn,
      taglineAr: tool.taglineAr
    }))
  });
}
