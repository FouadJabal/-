import type { Metadata } from "next";
import { Cairo, Tajawal, Inter } from "next/font/google";
import "./globals.css";
import { getLocaleFromCookies, dir } from "@/lib/i18n";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { siteUrl } from "@/lib/utils";

const cairo = Cairo({ subsets: ["latin", "arabic"], variable: "--font-cairo", display: "swap" });
const tajawal = Tajawal({
  subsets: ["arabic", "latin"],
  weight: ["400", "500", "700"],
  variable: "--font-tajawal",
  display: "swap"
});
const inter = Inter({ subsets: ["latin"], variable: "--font-inter", display: "swap" });

export async function generateMetadata(): Promise<Metadata> {
  const locale = getLocaleFromCookies();
  const isAr = locale === "ar";

  return {
    metadataBase: new URL(siteUrl()),
    title: {
      default: isAr
        ? "فؤاد آراب AI — دليلك العربي لأدوات الذكاء الاصطناعي"
        : "FouadArabAI — The Arabic-first AI Tools Directory",
      template: "%s | FouadArabAI"
    },
    description: isAr
      ? "اكتشف وقارن أفضل أدوات الذكاء الاصطناعي للكتابة والتصميم والبرمجة والإنتاجية، بالعربية والإنجليزية."
      : "Discover and compare the best AI tools for writing, design, coding and productivity, in Arabic and English.",
    openGraph: {
      type: "website",
      siteName: "FouadArabAI",
      url: siteUrl(),
      locale: isAr ? "ar_AR" : "en_US"
    },
    twitter: {
      card: "summary_large_image"
    },
    robots: {
      index: true,
      follow: true
    }
  };
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  const locale = getLocaleFromCookies();

  return (
    <html
      lang={locale}
      dir={dir(locale)}
      // No "dark" class is added here yet — dark mode is wired up at the
      // config/CSS level only, per the current request. Add "dark" to this
      // class list (e.g. via a cookie/localStorage-driven toggle, the same
      // pattern LanguageToggle already uses for locale) whenever a theme
      // switcher is actually built.
      suppressHydrationWarning
      className={`${cairo.variable} ${tajawal.variable} ${inter.variable}`}
    >
      <body className={locale === "ar" ? "font-arabic" : "font-body"}>
        <Header locale={locale} />
        <main>{children}</main>
        <Footer locale={locale} />
      </body>
    </html>
  );
}
