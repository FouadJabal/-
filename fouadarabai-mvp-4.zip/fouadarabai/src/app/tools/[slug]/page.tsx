import type { Metadata } from "next";
import { notFound } from "next/navigation";
import Link from "next/link";
import { getLocaleFromCookies, pick, t } from "@/lib/i18n";
import { Container } from "@/components/Container";
import { ToolCard } from "@/components/ToolCard";
import { SponsoredBadge } from "@/components/SponsoredBadge";
import { getRelatedTools, getToolBySlug, incrementToolView } from "@/lib/data";
import { siteUrl } from "@/lib/utils";

export async function generateMetadata({
  params
}: {
  params: { slug: string };
}): Promise<Metadata> {
  const tool = await getToolBySlug(params.slug);
  if (!tool) return {};

  const locale = getLocaleFromCookies();
  const name = pick(tool, "name", locale);
  const tagline = pick(tool, "tagline", locale);

  return {
    title: name,
    description: tagline,
    alternates: { canonical: siteUrl(`/tools/${tool.slug}`) },
    openGraph: {
      title: name,
      description: tagline,
      url: siteUrl(`/tools/${tool.slug}`),
      images: tool.screenshotUrl ? [tool.screenshotUrl] : undefined
    }
  };
}

export default async function ToolDetailsPage({ params }: { params: { slug: string } }) {
  const locale = getLocaleFromCookies();
  const dict = t(locale);

  const tool = await getToolBySlug(params.slug);
  if (!tool) notFound();

  // Awaited deliberately: on serverless (Vercel), an un-awaited promise can be
  // killed when the response finishes, silently dropping the write.
  await incrementToolView(tool.id);

  const related = await getRelatedTools(tool.categoryId, tool.id, 4);

  const name = pick(tool, "name", locale);
  const tagline = pick(tool, "tagline", locale);
  const description = pick(tool, "description", locale);
  const categoryName = pick(tool.category, "name", locale);

  const jsonLd = {
    "@context": "https://schema.org",
    "@type": "SoftwareApplication",
    name,
    description: tagline,
    applicationCategory: categoryName,
    offers: tool.startingPrice
      ? { "@type": "Offer", price: tool.startingPrice }
      : undefined,
    url: siteUrl(`/tools/${tool.slug}`)
  };

  return (
    <Container>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }}
      />

      <div className="py-12">
        <nav className="mb-6 text-sm text-ink/50">
          <Link href="/tools" className="hover:text-indigo">{dict.allTools}</Link>
          <span className="mx-2">/</span>
          <span>{name}</span>
        </nav>

        <div className="flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between">
          <div>
            <div className="mb-2 flex items-center gap-2">
              {tool.isSponsored && <SponsoredBadge label={dict.sponsored} />}
              {tool.isVerified && (
                <span className="rounded-full bg-teal/10 px-2.5 py-0.5 text-xs font-medium text-teal">
                  {dict.verified}
                </span>
              )}
            </div>
            <h1 className="font-display text-3xl font-bold text-ink">{name}</h1>
            <p className="mt-2 max-w-2xl font-body text-ink/70">{tagline}</p>
          </div>

          <a
            href={`/out/${tool.slug}`}
            target="_blank"
            rel="sponsored nofollow noopener"
            className="shrink-0 rounded-xl2 bg-indigo px-6 py-3 text-center font-medium text-white hover:bg-indigo-dark"
          >
            {dict.visitWebsite}
          </a>
        </div>

        <div className="mt-10 grid grid-cols-1 gap-10 lg:grid-cols-3">
          <div className="lg:col-span-2">
            <h2 className="font-display text-lg font-bold text-ink">
              {locale === "ar" ? "نبذة" : "Overview"}
            </h2>
            <p className="mt-3 whitespace-pre-line font-body leading-relaxed text-ink/80">
              {description}
            </p>
          </div>

          <aside className="rounded-xl2 border border-line bg-paper p-5">
            <dl className="space-y-4 text-sm">
              <div>
                <dt className="text-ink/50">{dict.categories}</dt>
                <dd className="mt-1 font-medium text-ink">{categoryName}</dd>
              </div>
              {tool.startingPrice && (
                <div>
                  <dt className="text-ink/50">{dict.pricing}</dt>
                  <dd className="mt-1 font-medium text-ink">{tool.startingPrice}</dd>
                </div>
              )}
            </dl>
          </aside>
        </div>

        {related.length > 0 && (
          <div className="mt-16">
            <h2 className="mb-6 font-display text-xl font-bold text-ink">
              {locale === "ar" ? "أدوات ذات صلة" : "Related Tools"}
            </h2>
            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
              {related.map((t2) => (
                <ToolCard
                  key={t2.id}
                  tool={{ ...t2, category: tool.category }}
                  locale={locale}
                />
              ))}
            </div>
          </div>
        )}
      </div>
    </Container>
  );
}
