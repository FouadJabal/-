import type { Metadata } from "next";
import Link from "next/link";
import { getLocaleFromCookies, t } from "@/lib/i18n";
import { Container } from "@/components/Container";
import { SearchBar } from "@/components/SearchBar";
import { ToolCard } from "@/components/ToolCard";
import { getAllTools, getCategories } from "@/lib/data";
import { siteUrl } from "@/lib/utils";

export async function generateMetadata(): Promise<Metadata> {
  const locale = getLocaleFromCookies();
  const isAr = locale === "ar";

  return {
    title: isAr ? "دليل أدوات الذكاء الاصطناعي" : "AI Tools Directory",
    description: isAr
      ? "تصفح وابحث في دليل فؤاد آراب AI الكامل لأدوات الذكاء الاصطناعي، مصنّفة حسب الفئة."
      : "Browse and search the full FouadArabAI directory of AI tools, filterable by category.",
    alternates: { canonical: siteUrl("/tools") }
  };
}

export default async function ToolsPage({
  searchParams
}: {
  searchParams: { q?: string; category?: string; page?: string };
}) {
  const locale = getLocaleFromCookies();
  const dict = t(locale);

  const page = Number(searchParams.page ?? "1") || 1;
  const query = searchParams.q?.trim() || undefined;
  const categorySlug = searchParams.category || undefined;

  const [{ items, pageCount }, categories] = await Promise.all([
    getAllTools({ query, categorySlug, page }),
    getCategories()
  ]);

  return (
    <Container>
      <div className="py-12">
        <h1 className="font-display text-3xl font-bold text-ink">{dict.allTools}</h1>

        <div className="mt-6 flex flex-col gap-4 sm:flex-row sm:items-center">
          <SearchBar placeholder={dict.searchPlaceholder} defaultValue={query} />
        </div>

        <div className="mt-4 flex flex-wrap gap-2">
          <Link
            href="/tools"
            className={`rounded-full px-3 py-1 text-sm ${
              !categorySlug ? "bg-indigo text-white" : "border border-line text-ink/70"
            }`}
          >
            {dict.allTools}
          </Link>
          {categories.map((c) => (
            <Link
              key={c.id}
              href={`/tools?category=${c.slug}`}
              className={`rounded-full px-3 py-1 text-sm ${
                categorySlug === c.slug ? "bg-indigo text-white" : "border border-line text-ink/70"
              }`}
            >
              {locale === "ar" ? c.nameAr : c.nameEn}
            </Link>
          ))}
        </div>

        {items.length === 0 ? (
          <p className="mt-16 text-center font-body text-ink/60">{dict.noResults}</p>
        ) : (
          <div className="mt-8 grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {items.map((tool) => (
              <ToolCard key={tool.id} tool={tool} locale={locale} />
            ))}
          </div>
        )}

        {pageCount > 1 && (
          <div className="mt-10 flex justify-center gap-2">
            {Array.from({ length: pageCount }, (_, i) => i + 1).map((p) => (
              <Link
                key={p}
                href={`/tools?${new URLSearchParams({
                  ...(query ? { q: query } : {}),
                  ...(categorySlug ? { category: categorySlug } : {}),
                  page: String(p)
                }).toString()}`}
                className={`h-9 w-9 rounded-full text-center text-sm leading-9 ${
                  p === page ? "bg-indigo text-white" : "border border-line text-ink/70"
                }`}
              >
                {p}
              </Link>
            ))}
          </div>
        )}
      </div>
    </Container>
  );
}
