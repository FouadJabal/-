import { cookies } from "next/headers";

export type Locale = "ar" | "en";

export const LOCALE_COOKIE = "fa_locale";

export const dictionary = {
  ar: {
    siteName: "فؤاد آراب AI",
    tagline: "دليلك العربي لأفضل أدوات الذكاء الاصطناعي",
    searchPlaceholder: "ابحث عن أداة ذكاء اصطناعي...",
    nav: { tools: "الأدوات", categories: "التصنيفات", home: "الرئيسية" },
    heroCta: "استكشف الأدوات",
    heroSubCta: "تصفح حسب التصنيف",
    featured: "أدوات مميزة",
    sponsored: "برعاية",
    allTools: "كل الأدوات",
    categories: "التصنيفات",
    visitWebsite: "زيارة الموقع",
    verified: "موثّقة",
    pricing: "التسعير",
    noResults: "لم يتم العثور على أدوات مطابقة",
    footerRights: "جميع الحقوق محفوظة",
    switchLang: "English"
  },
  en: {
    siteName: "FouadArabAI",
    tagline: "The Arabic-first directory of the best AI tools",
    searchPlaceholder: "Search for an AI tool...",
    nav: { tools: "Tools", categories: "Categories", home: "Home" },
    heroCta: "Explore Tools",
    heroSubCta: "Browse by Category",
    featured: "Featured Tools",
    sponsored: "Sponsored",
    allTools: "All Tools",
    categories: "Categories",
    visitWebsite: "Visit Website",
    verified: "Verified",
    pricing: "Pricing",
    noResults: "No matching tools found",
    footerRights: "All rights reserved",
    switchLang: "العربية"
  }
} as const;

function envDefaultLocale(): Locale {
  return process.env.NEXT_PUBLIC_DEFAULT_LOCALE === "en" ? "en" : "ar"; // Arabic-first default
}

export function getLocaleFromCookies(): Locale {
  const cookieLocale = cookies().get(LOCALE_COOKIE)?.value;
  if (cookieLocale === "en" || cookieLocale === "ar") return cookieLocale;
  return envDefaultLocale();
}

export function t(locale: Locale) {
  return dictionary[locale];
}

export function dir(locale: Locale): "rtl" | "ltr" {
  return locale === "ar" ? "rtl" : "ltr";
}

/** Pick the field matching the current locale from a bilingual record. */
export function pick<T extends Record<string, unknown>>(
  obj: T,
  baseKey: string,
  locale: Locale
): string {
  const key = `${baseKey}${locale === "ar" ? "Ar" : "En"}`;
  return (obj[key] as string) ?? "";
}
