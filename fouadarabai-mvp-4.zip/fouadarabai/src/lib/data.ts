import { Prisma } from "@prisma/client";
import { prisma } from "@/lib/prisma";

export async function getCategories() {
  return prisma.category.findMany({
    orderBy: { sortOrder: "asc" },
    include: { _count: { select: { tools: true } } }
  });
}

export async function getCategoryBySlug(slug: string) {
  return prisma.category.findUnique({ where: { slug } });
}

export async function getSponsoredTools(limit = 4) {
  return prisma.tool.findMany({
    where: {
      isPublished: true,
      isSponsored: true,
      OR: [{ sponsoredUntil: null }, { sponsoredUntil: { gte: new Date() } }]
    },
    orderBy: [{ sponsorRank: "asc" }, { createdAt: "desc" }],
    take: limit,
    include: { category: true }
  });
}

export async function getFeaturedTools(limit = 8) {
  return prisma.tool.findMany({
    where: { isPublished: true, isFeatured: true },
    orderBy: { createdAt: "desc" },
    take: limit,
    include: { category: true }
  });
}

export async function getAllTools(params: {
  categorySlug?: string;
  query?: string;
  page?: number;
  pageSize?: number;
}) {
  const { categorySlug, query, page = 1, pageSize = 24 } = params;

  const where: Prisma.ToolWhereInput = {
    isPublished: true,
    ...(categorySlug ? { category: { slug: categorySlug } } : {}),
    ...(query
      ? {
          OR: [
            { nameEn: { contains: query, mode: "insensitive" } },
            { nameAr: { contains: query, mode: "insensitive" } },
            { taglineEn: { contains: query, mode: "insensitive" } },
            { taglineAr: { contains: query, mode: "insensitive" } },
            { descriptionEn: { contains: query, mode: "insensitive" } },
            { descriptionAr: { contains: query, mode: "insensitive" } }
          ]
        }
      : {})
  };

  const [items, total] = await Promise.all([
    prisma.tool.findMany({
      where,
      orderBy: [{ isSponsored: "desc" }, { isFeatured: "desc" }, { createdAt: "desc" }],
      skip: (page - 1) * pageSize,
      take: pageSize,
      include: { category: true }
    }),
    prisma.tool.count({ where })
  ]);

  return { items, total, page, pageSize, pageCount: Math.max(1, Math.ceil(total / pageSize)) };
}

export async function getToolBySlug(slug: string) {
  return prisma.tool.findUnique({
    where: { slug },
    include: { category: true, tags: { include: { tag: true } } }
  });
}

export async function getRelatedTools(categoryId: string, excludeId: string, limit = 4) {
  return prisma.tool.findMany({
    where: { categoryId, isPublished: true, id: { not: excludeId } },
    take: limit,
    orderBy: { isFeatured: "desc" }
  });
}

/** View/click counters. Never throw into the request path — a failed counter write should not break the page. */
export async function incrementToolView(id: string) {
  try {
    await prisma.tool.update({ where: { id }, data: { viewCount: { increment: 1 } } });
  } catch {
    // non-critical; ignore
  }
}

export async function incrementToolClick(id: string) {
  try {
    await prisma.tool.update({ where: { id }, data: { clickCount: { increment: 1 } } });
  } catch {
    // non-critical; ignore
  }
}
