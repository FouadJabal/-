# FouadArabAI

The Arabic-first, bilingual (Arabic/English) directory of AI tools — homepage, searchable/filterable
tools directory, tool detail pages, categories, RTL/LTR support, SEO foundation, affiliate-ready
outbound links, and sponsored placements.

Read `docs/` for the full documentation set:
- `ARCHITECTURE.md` — how the app is put together and why
- `FOLDER_STRUCTURE.md` — file layout reference
- `DATABASE_SCHEMA.md` — Prisma models explained
- `DEPLOYMENT.md` — step-by-step Vercel deployment
- `ENVIRONMENT_VARIABLES.md` — required config
- `LAUNCH_CHECKLIST.md`, `SEO_CHECKLIST.md`, `TESTING_CHECKLIST.md`
- `MAINTENANCE_GUIDE.md` — day-2 operations
- `FUTURE_ROADMAP.md` — Marketplace/Academy/Community/Payments, planned but not built yet

## Quick start (local development)

```bash
npm install
cp .env.example .env
# edit .env with a local or hosted Postgres connection string

npx prisma migrate deploy   # create tables from the committed migrations
npm run db:seed             # add sample bilingual tools
npm run dev                  # http://localhost:3000
```

## Quick deploy

See `docs/DEPLOYMENT.md`. Short version: push to GitHub, import into Vercel, set the environment
variables from `.env.example`, deploy — migrations run automatically as part of the build — then
optionally run `npm run db:seed` once against the production `DATABASE_URL` to add sample tools.

## Scope note

This is the MVP only: Homepage, Tools Directory, Tool Details, Categories, bilingual search,
RTL/LTR, SEO foundation, affiliate-ready links, sponsored tools. Marketplace, Academy, Community,
Auth, Payments, and an AI chatbot are intentionally out of scope for this phase — see
`docs/FUTURE_ROADMAP.md`.
